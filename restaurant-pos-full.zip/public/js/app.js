
let SETTINGS = null;
async function api(path, opts={}) {
  const res = await fetch('/api'+path, { 
    headers: { 'Content-Type': 'application/json' }, 
    credentials: 'include', 
    ...opts 
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

async function loadAdminLists() {
  const menuList = document.getElementById('menu-list');
  const tableList = document.getElementById('table-list');
  if (!menuList && !tableList) return;
  const [menu, tables] = await Promise.all([api('/menu.php'), api('/tables.php')]);
  if (menuList) {
    menuList.innerHTML = menu.items.map(i => `<div>${i.name} - ${(i.price_cents/100).toFixed(2)} <button onclick="editMenu(${i.id}, '${i.name.replace(/'/g,"&#39;")}', ${i.price_cents}, ${i.tax_rate})">Edit</button></div>`).join('');
  }
  if (tableList) {
    tableList.innerHTML = tables.items.map(t => `<div>${t.label} (cap ${t.capacity})</div>`).join('');
  }
}
document.addEventListener('DOMContentLoaded', loadAdminLists);
document.addEventListener('DOMContentLoaded', loadSettings);

function openMenuModal(){ document.getElementById('menu-modal').classList.remove('hidden'); }
function closeMenuModal(){ document.getElementById('menu-modal').classList.add('hidden'); }
function editMenu(id,name,price_cents,tax){ 
  openMenuModal(); 
  document.getElementById('menu-id').value=id;
  document.getElementById('menu-name').value=name;
  document.getElementById('menu-price').value=(price_cents/100).toFixed(2);
  document.getElementById('menu-tax').value=tax;
}
async function saveMenuItem(e){
  e.preventDefault();
  const f = e.target;
  const body = {
    id: f['id'].value? Number(f['id'].value): null,
    name: f['name'].value,
    price: parseFloat(f['price'].value),
    tax_rate: parseFloat(f['tax_rate'].value||'0')
  };
  await api('/menu.php', { method:'POST', body: JSON.stringify(body)});
  closeMenuModal();
  loadAdminLists();
  return false;
}
async function addTable(){
  const label = prompt('Table label?');
  if (!label) return;
  await api('/tables.php', { method:'POST', body: JSON.stringify({label, capacity:4})});
  loadAdminLists();
}

let currentOrder = { table_id:null, table_label:null, items:[], order_id:null };
function openOrder(table_id,label){
  currentOrder = { table_id, table_label:label, items:[], order_id:null };
  document.getElementById('ticket-title').textContent = `Ticket - ${label}`;
  renderTicket();
}
function addItemToCurrent(id,name,price_cents,tax_rate){
  currentOrder.items.push({ id, name, price_cents, tax_rate, qty:1 });
  renderTicket();
}
function clearTicket(){ currentOrder.items=[]; renderTicket(); }
function renderTicket(){
  const hold = document.getElementById('ticket-lines');
  let subtotal=0, tax=0;
  hold.innerHTML = currentOrder.items.map((it,idx)=>{
    const line = it.price_cents * it.qty;
    subtotal += line; 
    tax += Math.round(line * it.tax_rate);
    return `<div class='line'>
      ${it.name} x <input type='number' min='1' value='${it.qty}' onchange='chgQty(${idx}, this.value)' style='width:60px'> 
      <span style='float:right'>${currency()}${(line/100).toFixed(2)}</span>
    </div>`;
  }).join('');
  if (SETTINGS && SETTINGS.tax_mode === 'global') {
    tax = Math.round(subtotal * (parseFloat(SETTINGS.vat_rate||0) || 0));
  }
  document.getElementById('subtotal').textContent = currency()+(subtotal/100).toFixed(2);
  document.getElementById('tax').textContent = currency()+(tax/100).toFixed(2);
  document.getElementById('total').textContent = currency()+((subtotal+tax)/100).toFixed(2);
}
function currency(){ return (SETTINGS && SETTINGS.currency_symbol) ? SETTINGS.currency_symbol : '$'; }
function chgQty(idx,val){ currentOrder.items[idx].qty = parseInt(val||'1'); renderTicket(); }
async function sendToKitchen(){
  if (!currentOrder.table_id || currentOrder.items.length===0) return alert('Select a table and add items.');
  const res = await api('/orders.php', { method:'POST', body: JSON.stringify({
    action:'send',
    table_id: currentOrder.table_id,
    items: currentOrder.items.map(i => ({ item_id:i.id, qty:i.qty, price_cents:i.price_cents, tax_rate:i.tax_rate }))
  })});
  currentOrder.order_id = res.order_id;
  alert('Sent to kitchen!');
}
async function payOrder(){
  if (!currentOrder.order_id) return alert('Send to kitchen first.');
  const total = document.getElementById('total').textContent.replace(currency(), '');
  const sel = document.getElementById('pay-method');
  const ref = document.getElementById('pay-ref');
  const method = sel && sel.value ? sel.value : 'cash';
  await api('/orders.php', { method:'POST', body: JSON.stringify({
    action:'pay', order_id: currentOrder.order_id, method, reference: (ref?ref.value:null), amount: parseFloat(total)
  })});
  window.location.href = `/receipt.php?order_id=${currentOrder.order_id}`;
}

async function loadKDS(){
  const el = document.getElementById('kds-board'); if (!el) return;
  const data = await api('/orders.php?scope=kds');
  el.innerHTML = data.items.map(oi => `
    <div class="kds-card">
      <h4>Order #${oi.order_id} • ${oi.item_name}</h4>
      <div>Qty: ${oi.qty} <span class="badge">${oi.kds_status}</span></div>
      <button onclick="kdsUpdate(${oi.id}, 'in_progress')">Start</button>
      <button onclick="kdsUpdate(${oi.id}, 'ready')">Ready</button>
      <button onclick="kdsUpdate(${oi.id}, 'served')">Served</button>
    </div>
  `).join('');
}
async function kdsUpdate(id, status){
  await api('/orders.php', { method:'POST', body: JSON.stringify({ action:'kds', item_id:id, status })});
  loadKDS();
}
setInterval(loadKDS, 4000);
document.addEventListener('DOMContentLoaded', loadKDS);

async function loadDaily(){
  const date = document.getElementById('rep-date').value;
  const out = document.getElementById('rep-output');
  const rep = await api('/reports.php?date='+encodeURIComponent(date));
  out.innerHTML = `<pre>${JSON.stringify(rep,null,2)}</pre>`;
}

async function loadSettings(){
  try {
    SETTINGS = await api('/settings.php');
    const sel = document.getElementById('pay-method');
    if (sel && SETTINGS.payment_methods) {
      sel.innerHTML = SETTINGS.payment_methods.map(m=>`<option value="${m}">${m.toUpperCase()}</option>`).join('');
    }
    renderTicket();
  } catch(e) { console.warn('Settings not loaded', e); }
}

async function saveSettings(e){
  e.preventDefault();
  const f = document.getElementById('settings-form');
  const fd = new FormData(f);
  const methods = fd.getAll('payment_methods[]');
  const body = {
    restaurant_name: fd.get('restaurant_name'),
    restaurant_address: fd.get('restaurant_address'),
    restaurant_phone: fd.get('restaurant_phone'),
    receipt_footer: fd.get('receipt_footer'),
    currency_symbol: fd.get('currency_symbol'),
    vat_rate: parseFloat(fd.get('vat_rate')||'0'),
    tax_mode: fd.get('tax_mode'),
    payment_methods: methods
  };
  await api('/settings.php', { method:'POST', body: JSON.stringify(body) });
  alert('Saved.');
  return false;
}
