
<?php
require __DIR__ . '/../config.php';
require_login(['admin','cashier']);
$db = get_db();
$date = $_GET['date'] ?? date('Y-m-d');
$start = $date.' 00:00:00';
$end = $date.' 23:59:59';
$totStmt = $db->prepare('SELECT SUM(p.amount_cents) as gross_cents FROM payments p JOIN orders o ON o.id=p.order_id WHERE o.closed_at BETWEEN ? AND ?');
$totStmt->execute([$start,$end]);
$gross = (int)($totStmt->fetch(PDO::FETCH_ASSOC)['gross_cents'] ?? 0);
$itemStmt = $db->prepare('SELECT mi.name, SUM(oi.qty) as qty, SUM(oi.qty*oi.price_cents) as sales_cents FROM order_items oi JOIN orders o ON o.id=oi.order_id JOIN menu_items mi ON mi.id=oi.item_id WHERE o.closed_at BETWEEN ? AND ? GROUP BY mi.name ORDER BY sales_cents DESC');
$itemStmt->execute([$start,$end]);
$items = $itemStmt->fetchAll(PDO::FETCH_ASSOC);
$byMethodStmt = $db->prepare('SELECT p.method, SUM(p.amount_cents) as cents FROM payments p JOIN orders o ON o.id=p.order_id WHERE o.closed_at BETWEEN ? AND ? GROUP BY p.method');
$byMethodStmt->execute([$start,$end]);
$byMethod = $byMethodStmt->fetchAll(PDO::FETCH_ASSOC);
echo json_encode([
  'date'=>$date,
  'gross_sales'=>$gross,
  'gross_sales_formatted'=>number_format($gross/100,2),
  'best_sellers'=>$items,
  'method_breakdown'=>$byMethod
]);
