
<?php
require __DIR__ . '/../config.php';
require_login(['admin','cashier','waiter','kitchen']);
if ($_SERVER['REQUEST_METHOD']==='GET') {
    json_response(get_settings());
}
if ($_SERVER['REQUEST_METHOD']==='POST') {
    require_login(['admin']);
    $data = json_decode(file_get_contents('php://input'), true) ?? [];
    $allow = ['restaurant_name','restaurant_address','restaurant_phone','currency_symbol','vat_rate','tax_mode','payment_methods','receipt_footer'];
    foreach ($allow as $k) {
        if (array_key_exists($k, $data)) {
            set_setting($k, $data[$k]);
        }
    }
    json_response(['ok'=>true, 'settings'=>get_settings()]);
}
json_response(['error'=>'Method not allowed'], 405);
