
Restaurant POS (PHP + SQLite) - Full source for quick local testing.

How to run locally (quick):
1. Make sure you have PHP 8+ installed.
2. From this folder run:
   php -S localhost:8080 -t public
3. Open browser: http://localhost:8080/init_db.php (run once)
4. Login at http://localhost:8080/ with demo users:
   - admin@example.com / admin123
   - cashier@example.com / cashier123
   - waiter@example.com / waiter123
   - kitchen@example.com / kitchen123
